package com.example.mad_assignment;

public interface ItemOnClick {
    void itemOnClick(int position);
}
